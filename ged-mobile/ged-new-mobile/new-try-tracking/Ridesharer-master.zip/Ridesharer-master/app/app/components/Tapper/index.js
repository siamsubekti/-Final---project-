import Tapper from './Tapper';

export default Tapper;