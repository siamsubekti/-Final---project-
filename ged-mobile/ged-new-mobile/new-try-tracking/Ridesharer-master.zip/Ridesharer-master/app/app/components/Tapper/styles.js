import { StyleSheet } from 'react-native';

export default StyleSheet.create({
	button_container: {
		margin: 10
	},
});