#import <React/RCTConvert.h>

@interface RCTConvert (RNGPAutocompleteTypeFilter)

@end
