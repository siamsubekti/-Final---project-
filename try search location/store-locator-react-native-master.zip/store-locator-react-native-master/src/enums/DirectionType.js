const DirectionType = {
  Driving: 'mapbox/driving-traffic',
  Walking: 'mapbox/walking',
  Cycling: 'mapbox/cycling',
  Default: 'mapbox/driving-traffic',
};

export default DirectionType;
