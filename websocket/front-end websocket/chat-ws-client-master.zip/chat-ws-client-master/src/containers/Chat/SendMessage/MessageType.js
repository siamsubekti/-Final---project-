
export default  class MessageType {
    static TEXT_MESSAGE = 'TEXT_MESSAGE';
    static USER_JOINED = 'USER_JOINED';
    static USER_LEFT = 'USER_LEFT';
    static USER_JOINED_ACK = 'USER_JOINED_ACK';
}