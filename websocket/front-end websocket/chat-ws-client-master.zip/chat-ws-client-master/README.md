# Simple chat client app written in React

## Demo
https://jasofalcon.github.io/chat-ws-client/

## Backend
In order to use the app, please clone this simple backend app - https://github.com/jasofalcon/chat-ws-java
Fire-up the server and then continue with setting-up the frontend app

## Setup
``` npm i ```

## Run
``` npm start ```
