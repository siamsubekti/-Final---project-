import baby_deer_45px from '../styles/avatars/45px/baby-deer.png';
import blue_bird_45px from '../styles/avatars/45px/blue-bird.png';
import colorful_cock_45px from '../styles/avatars/45px/colorful-cock.png';
import cute_bear_45px from '../styles/avatars/45px/cute-bear.png';
import forest_cat_45px from '../styles/avatars/45px/forest-cat.png';
import funky_monkey_45px from '../styles/avatars/45px/funky-monkey.png';
import happy_turtle_45px from '../styles/avatars/45px/happy-turtle.png';
import happy_chipmunk_45px from '../styles/avatars/45px/happy-chimpunk.png';
import jungle_tiger_45px from '../styles/avatars/45px/jungle-tiger.png';
import king_lion_45px from '../styles/avatars/45px/king-lion.png';
import little_elephant_45px from '../styles/avatars/45px/little-elephant.png';
import long_giraffe_45px from '../styles/avatars/45px/long-giraffe.png';
import night_owl_45px from '../styles/avatars/45px/night-owl.png';
import parrot_arra_45px from '../styles/avatars/45px/parrot-arra.png';
import safari_camel_45px from '../styles/avatars/45px/safari-camel.png';
import sleeping_cheetah_45px from '../styles/avatars/45px/sleeping-cheetah.png';
import striped_zebra_45px from '../styles/avatars/45px/striped-zebra.png';
import tropical_toucan_45px from '../styles/avatars/45px/tropical-toucan.png';
import white_rabbit_45px from '../styles/avatars/45px/white-rabbit.png';
import wild_eagle_45px from '../styles/avatars/45px/wild-eagle.png';
import honey_bee_45px from '../styles/avatars/45px/Honey-Bee.png';
import angry_crocodile_45px from '../styles/avatars/45px/Angry-Crocodile.png';
import mountain_kangaroo_45px from '../styles/avatars/45px/Mountain-Kangaroo.png';
import scary_snake_45px from '../styles/avatars/45px/Scary-Snake.png';
import greenland_reindeer_45px from '../styles/avatars/45px/Greenland-Reindeer.png';
import crazy_frog_45px from '../styles/avatars/45px/Crazy-Frog.png';
import black_pig_45px from '../styles/avatars/45px/Black-Pig.png';
import red_fox_45px from '../styles/avatars/45px/Red-Fox.png';
import bamboo_panda_45px from '../styles/avatars/45px/Bamboo-Panda.png';
import cuddly_koala_45px from '../styles/avatars/45px/Cuddly-Koala.png';
import fast_ostrich_45px from '../styles/avatars/45px/Fast-Ostrich.png';
import brown_meerkat_45px from '../styles/avatars/45px/Brown-Meerkat.png';


import baby_deer_28px from '../styles/avatars/28px/baby-deer.png';
import blue_bird_28px from '../styles/avatars/28px/blue-bird.png';
import colorful_cock_28px from '../styles/avatars/28px/colorful-cock.png';
import cute_bear_28px from '../styles/avatars/28px/cute-bear.png';
import forest_cat_28px from '../styles/avatars/28px/forest-cat.png';
import funky_monkey_28px from '../styles/avatars/28px/funky-monkey.png';
import happy_turtle_28px from '../styles/avatars/28px/happy-turtle.png';
import happy_chipmunk_28px from '../styles/avatars/28px/happy-chimpunk.png';
import jungle_tiger_28px from '../styles/avatars/28px/jungle-tiger.png';
import king_lion_28px from '../styles/avatars/28px/king-lion.png';
import little_elephant_28px from '../styles/avatars/28px/little-elephant.png';
import long_giraffe_28px from '../styles/avatars/28px/long-giraffe.png';
import night_owl_28px from '../styles/avatars/28px/night-owl.png';
import parrot_arra_28px from '../styles/avatars/28px/parrot-arra.png';
import safari_camel_28px from '../styles/avatars/28px/safari-camel.png';
import sleeping_cheetah_28px from '../styles/avatars/28px/sleeping-cheetah.png';
import striped_zebra_28px from '../styles/avatars/28px/striped-zebra.png';
import tropical_toucan_28px from '../styles/avatars/28px/tropical-toucan.png';
import white_rabbit_28px from '../styles/avatars/28px/white-rabbit.png';
import wild_eagle_28px from '../styles/avatars/28px/wild-eagle.png';
import honey_bee_28px from '../styles/avatars/28px/Honey-Bee.png';
import angry_crocodile_28px from '../styles/avatars/28px/Angry-Crocodile.png';
import mountain_kangaroo_28px from '../styles/avatars/28px/Mountain-Kangaroo.png';
import scary_snake_28px from '../styles/avatars/28px/Scary-Snake.png';
import greenland_reindeer_28px from '../styles/avatars/28px/Greenland-Reindeer.png';
import crazy_frog_28px from '../styles/avatars/28px/Crazy-Frog.png';
import black_pig_28px from '../styles/avatars/28px/Black-Pig.png';
import red_fox_28px from '../styles/avatars/28px/Red-Fox.png';
import bamboo_panda_28px from '../styles/avatars/28px/Bamboo-Panda.png';
import cuddly_koala_28px from '../styles/avatars/28px/Cuddly-Koala.png';
import fast_ostrich_28px from '../styles/avatars/28px/Fast-Ostrich.png';
import brown_meerkat_28px from '../styles/avatars/28px/Brown-Meerkat.png';

export default {
  baby_deer_45px,
  blue_bird_45px,
  colorful_cock_45px,
  cute_bear_45px,
  forest_cat_45px,
  funky_monkey_45px,
  happy_chipmunk_45px,
  happy_turtle_45px,
  jungle_tiger_45px,
  king_lion_45px,
  little_elephant_45px,
  long_giraffe_45px,
  night_owl_45px,
  parrot_arra_45px,
  safari_camel_45px,
  sleeping_cheetah_45px,
  striped_zebra_45px,
  tropical_toucan_45px,
  white_rabbit_45px,
  honey_bee_45px,
  angry_crocodile_45px,
  mountain_kangaroo_45px,
  scary_snake_45px,
  greenland_reindeer_45px,
  crazy_frog_45px,
  black_pig_45px,
  red_fox_45px,
  bamboo_panda_45px,
  cuddly_koala_45px,
  fast_ostrich_45px,
  brown_meerkat_45px,
  wild_eagle_45px,
  baby_deer_28px,
  blue_bird_28px,
  colorful_cock_28px,
  cute_bear_28px,
  forest_cat_28px,
  funky_monkey_28px,
  happy_chipmunk_28px,
  happy_turtle_28px,
  jungle_tiger_28px,
  king_lion_28px,
  little_elephant_28px,
  long_giraffe_28px,
  night_owl_28px,
  parrot_arra_28px,
  safari_camel_28px,
  sleeping_cheetah_28px,
  striped_zebra_28px,
  tropical_toucan_28px,
  white_rabbit_28px,
  wild_eagle_28px,
  honey_bee_28px,
  angry_crocodile_28px,
  mountain_kangaroo_28px,
  scary_snake_28px,
  greenland_reindeer_28px,
  crazy_frog_28px,
  black_pig_28px,
  red_fox_28px,
  bamboo_panda_28px,
  cuddly_koala_28px,
  fast_ostrich_28px,
  brown_meerkat_28px,
};