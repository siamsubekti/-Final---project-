module.exports = {
    publishKey: 'YOUR_PUBLISH_KEY',
    subscribeKey: 'YOUR_SUBSCRIBE_KEY'
  };
  