module.exports = {
  forestChatChannel: 'demo-animal-forest',
};
